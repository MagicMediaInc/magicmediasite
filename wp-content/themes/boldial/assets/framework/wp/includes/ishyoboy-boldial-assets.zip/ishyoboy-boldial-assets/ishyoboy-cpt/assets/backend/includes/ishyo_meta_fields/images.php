<input type="button" class="button-secondary upload-<?php the_ID(); ?>" name="<?php echo $id?>" id="ishyoboy_images_upload" value="<?php echo $value?>" />
